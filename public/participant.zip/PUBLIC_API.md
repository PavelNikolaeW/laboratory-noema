# Публичный контракт Research Lab v0.1

Этот документ можно передавать разработчику харнеса и испытуемому агенту. Скрытые закономерности не входят в контракт. При реализации сгенерировать OpenAPI и публичные JSON Schema из DTO; схемы/примеры должны соответствовать этому документу.

## 1. Общие правила

- Prefix `/api/v1`. JSON UTF-8. Авторизация `Authorization: Bearer <participant-token>`, привязанная к одному run. Участник не создаёт новые run ради сброса бюджета.
- IDs — непрозрачные строки. Временные метки UTC ISO 8601. Монотонные номера событий целочисленные.
- Decimal-физические величины передаются строками; power, duration и enum-настройки — целые/строки согласно паспорту. Не принимать NaN/Infinity, лишние поля и значения вне диапазона.
- Все POST-команды, включая записи заметок/предсказаний/рецептов, требуют `Idempotency-Key`. Ключ scoped по run; сохраняется на всё прохождение.
- Тот же ключ с тем же канонизированным телом и маршрутом возвращает тот же ресурс без повторных эффекта/расхода. Другое тело/маршрут с прежним ключом: `409 idempotency_conflict`.
- Для изменения/измерения порции передаётся ожидаемый revision. Для двух входов — оба revision. Устаревший revision: `409 stale_revision`.
- GET не делает новое измерение, не продвигает физическое время и не расходует экспериментальные credits. Служебное ограничение частоты допустимо и отдельно от бюджета опытов.
- Ошибка: `{"error":{"code":"sample_busy","message":"...","retryable":true},"request_id":"..."}`. Без traceback, состава, скрытой фазы или коэффициентов.
- Типичные статусы: 401/403 доступ; 404 неизвестный публичный ID; 409 conflict/busy/consumed/insufficient_material; 422 invalid_parameters; 429 rate_limit или budget_exhausted с разными code.

## 2. Чтение

| Метод и путь | Ответ |
| --- | --- |
| GET `/session` | run_id, actor label, доступные действия, бюджет, текущие orders, последняя event sequence |
| GET `/instruments` | Паспорта: id, тип, status, action schemas, units, limits, costs |
| GET `/batches` | Доступные партии, публичные ярлыки, остаток материала, допустимый размер порции; без состава |
| GET `/standards` | standard_id, сертификат исходных измеряемых свойств, доступное количество; без состава |
| GET `/samples?cursor=&limit=` | Порции и cursor; фильтр status/batch_id |
| GET `/samples/{id}` | id, revision, status, batch/provenance, история, ссылки на последние observations |
| GET `/observations?sample_id=&cursor=&limit=` | Сохранённые измерения, а не новые показания |
| GET `/operations/{id}` | Статус, input refs, result/error, output sample refs, observation refs |
| GET `/events?after=0&limit=100` | События с sequence > after, next_after, has_more |
| GET `/orders` и `/orders/{id}` | Операторская заявка, критерии, бюджет, статус |
| GET `/recipes/{id}` | Сохранённый рецепт |
| GET `/submissions/{id}` | Результат независимой проверки |
| GET `/notes` и `/predictions` | Записи участника |

limit: 1–200, default 100. Порядок событий — серверный порядок фиксации; at-least-once polling, consumer дедуплицирует по event_id. next_after равен sequence последнего возвращённого события либо переданному after при пустой странице.

Sample не содержит автоматически свежих массы, температуры или отклика. Если свойства измерены, каждое показание ссылается на sample_revision; UI и агент видят устаревание после обработки. Публично запрошенная номинальная масса при отборе остаётся в provenance, но не называется измерением.

## 3. Единый запуск операций

POST `/operations`, ответ `202` с Operation DTO:

```json
{
  "kind": "heat",
  "instrument_id": "heater-1",
  "inputs": [{"sample_id": "sample-id", "revision": 1}],
  "parameters": {"power": 5, "duration": 12},
  "prediction_id": null
}
```

На принятии валидируются все параметры, revision, ресурсы, блокировки и бюджет. Принятая операция получает неизменяемый ID, атомарно резервирует входы/устройство/стоимость. В v0.1 занятый прибор возвращает busy, скрытой очереди нет.

| kind | instrument_id | inputs | parameters | Результат |
| --- | --- | --- | --- | --- |
| obtain | null | [] | batch_id, mass_g | Новая свежая порция |
| reference | null | [] | standard_id | Сертифицированный контрольный образец |
| split | null | один | fraction: строка, 0 < f < 1 | Две порции; исходная consumed |
| measure_mass | scale-1 | один | {} | Observation, образец не расходуется |
| measure_temperature | thermometer-1 | один | {} | Observation |
| measure_response | analyzer-1 | один | {} | Observation |
| heat | heater-1 | один | power: int 1–10, duration: int 1–120 | Тот же sample, новая revision |
| cool | cooler-1 | один | target_temperature_c: строка от 20 до 200 | Тот же sample, новая revision |
| separate | separator-1 | один | mode: "selective" | selected/remainder, исходная consumed |
| mix | mixer-1 | два различных | {} | Новый sample, оба входа consumed |

Размер порции: 0.1–100 г в пилотном профиле, с точностью ввода до 0.001 г. Запас партии и минимальный выход после split объявлены в паспорте. Проверка выхода не должна раскрывать скрытый состав; недостаточный размер объясняется общей массой/допуском операции.

Измерения тоже асинхронные операции, даже если выполняются быстро. Они блокируют вход/прибор на время выполнения, чтобы sample_revision был однозначным. Запрещено повторять один и тот же input дважды в mix.

```json
{
  "id": "operation-id",
  "status": "succeeded",
  "kind": "measure_response",
  "inputs": [{"sample_id": "sample-id", "revision": 2}],
  "result": {
    "observations": [{
      "id": "observation-id",
      "sample_id": "sample-id",
      "sample_revision": 2,
      "quantity": "response",
      "value": "73.000000",
      "unit": "response_unit",
      "instrument_id": "analyzer-1"
    }],
    "samples": []
  },
  "error": null
}
```

Число в примере иллюстративно, не эталон для любой партии. SampleRef = sample_id + revision. Статусы: accepted, running, succeeded, failed. Потеря HTTP-ответа не меняет статус; клиент сверяет по ID или повторяет исходный запрос с тем же ключом.

## 4. События и интеграция с харнесом

```json
{
  "event_id": "event-id",
  "sequence": 42,
  "kind": "operation.succeeded",
  "operation_id": "operation-id",
  "recorded_at": "2026-10-06T12:00:00Z",
  "payload": {"result_ref": "/api/v1/operations/operation-id"}
}
```

В v0.1 polling — обязательный транспорт, SSE необязателен. Харнес хранит соответствие своего operation_id и ID лаборатории, после пробуждения подгружает публичный результат и раскрывает его в контексте. Лаборатория не должна знать branch/episode IDs или внутреннее устройство памяти агента.

## 5. Стоимость и бюджеты

Пилотные значения, возвращаемые `/instruments` и `/session`: obtain 1 credit плюс списание материала; reference 2; split 1; любое измерение 1; heat 2 + power×duration/60; cool 1; separate 3; mix 2. Вычисления стоимости Decimal, без округления до целого. Невалидные запросы до принятия не списываются. Повтор с тем же ключом не списывается.

Неисправность backend до commit эффекта: состояние и резерв не расходуются, операция failed, резерв освобождён. При успешном commit стоимость окончательная. Сервис в v0.1 не имеет частично выполненных физических действий. Сетевой сбой после commit не повод вернуть ресурс.

Чтение, заметки и сохранение рецептов бесплатны в экспериментальных credits, но ограничены разумными payload/rate limits. Вызовы LLM оплачиваются/учитываются харнесом отдельно.

## 6. Предсказания и блокнот

POST `/predictions`: целевая величина, ожидаемое значение, необязательный интервал, planned_operation без prediction_id, текст гипотезы. Запись неизменяема после создания; operation может сослаться только на prediction, созданный до её принятия и совпадающий по planned_operation.

Для предсказания будущего отклика после heat участник сначала обрабатывает образец, затем фиксирует prediction на measure_response до этого измерения. Получение данных и запись предсказания после него не считается предсказанием. Сравнивается значение на совпадающем revision; более поздние изменения не подменяют цель.

POST `/notes`: text, optional sample_ids/observation_ids/order_id. Возвращает ID. Правки создают новую запись с supersedes, исходный текст сохраняется.

## 7. Заказы и рецепты

Order DTO: id, brief, batch_id, input_mass_g, response_min, yield_min, max_recipe_credits, validation_repeats, validation_cost, status. Предельные расходы на исследование показаны в run отдельно от стоимости итогового рецепта.

POST `/recipes`:

```json
{
  "name": "Обработка партии",
  "steps": [
    {"kind": "heat", "parameters": {"power": 5, "duration": 12}},
    {"kind": "cool", "parameters": {"target_temperature_c": "20"}}
  ],
  "applicability": "Проверяется для выбранной партии и массы",
  "evidence_ids": []
}
```

Recipe v0.1 — линейная последовательность над одной текущей порцией. Допустимы heat, cool, separate. Для separate обязательно `keep_output: "selected" | "remainder"`; отброшенная ветвь учитывается как потеря массы для выхода. Ограничение 1–20 шагов. Циклы, произвольный Python, смешивание/разделение ветвей внутри recipe не поддерживаются в v0.1. mix и split доступны для исследовательских опытов. Это явное ограничение MVP, не запрет агенту строить более общие модели в REPL.

POST `/submissions`: order_id, recipe_id. Возвращает submission_id, operation_id. Проверка выполняет рецепт на validation_repeats свежих порциях указанной партии и массы, затем охлаждает до 20 и оценивает материал. Материал проверки берётся из объявленного отдельного verification reserve; стоимость проверки заранее видна и списывается из run. Производственный рецепт оценивается отдельно от overhead проверки.

Проверка использует снимок текущей конфигурации приборов на момент принятия; изменения в середине одного validation недопустимы. Перед новым submission снимок может быть другим. Результат: pass/fail, measured_response, yield, recipe_credits по каждому повтору, причины провала, публичные observation refs. Формулы, состав и закрытые параметры не возвращаются.

Выход материала = масса сохранённой порции / исходная масса для этого повтора. Успех требует всех критериев на каждом повторе; валидатор не принимает заявленную участником оценку вместо собственного расчёта. Статус заказа completed только по успешной проверке.

Существование прежнего успешного submission не гарантирует актуальную пригодность рецепта после изменения оборудования. Исторический результат остаётся привязанным ко времени и наблюдениям.
